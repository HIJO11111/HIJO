import { useState } from 'react';
import { Mail, MessageSquare, Send, Github, Twitter } from 'lucide-react';
import { toast } from 'sonner';

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      toast.success('Message envoyé avec succès! Je vous répondrai bientôt.');
      setFormData({ name: '', email: '', subject: '', message: '' });
    } catch (error) {
      toast.error('Une erreur est survenue. Veuillez réessayer.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section id="contact" className="relative py-24 overflow-hidden">
      {/* Geometric background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-1/4 right-0 w-96 h-96 bg-accent/5 transform rotate-45" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-accent/5 transform -rotate-12" />
      </div>

      <div className="container relative z-10">
        {/* Section Header */}
        <div className="mb-16">
          <div className="inline-flex items-center gap-3 px-4 py-2 bg-secondary border-2 border-accent mb-6 transform -skew-x-12">
            <span className="text-sm font-bold text-accent transform skew-x-12">CONTACT</span>
          </div>
          <h2 className="text-5xl md:text-6xl font-display font-black mb-4 text-foreground">
            Parlons Ensemble
          </h2>
          <p className="text-lg text-foreground/60 max-w-2xl">
            Vous avez un projet intéressant ou une collaboration en tête? N'hésitez pas à me contacter.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 max-w-4xl">
          {/* Contact Info */}
          <div className="space-y-6 animate-in fade-in slide-in-from-left-8 duration-500">
            {/* Email */}
            <div className="relative p-6 bg-secondary border-2 border-foreground/20 hover:border-accent transition-all duration-200">
              <div className="absolute -top-2 -right-2 w-4 h-4 bg-accent" />
              <div className="flex items-start gap-4">
                <div className="p-2 bg-accent/10 border-2 border-accent">
                  <Mail size={20} className="text-accent" />
                </div>
                <div>
                  <h3 className="font-bold text-foreground mb-1">Email</h3>
                  <a
                    href="mailto:contact@hijo.dev"
                    className="text-foreground/60 hover:text-accent transition-colors font-medium"
                  >
                    contact@hijo.dev
                  </a>
                </div>
              </div>
            </div>

            {/* Discord */}
            <div className="relative p-6 bg-secondary border-2 border-foreground/20 hover:border-accent transition-all duration-200">
              <div className="absolute -bottom-2 -left-2 w-4 h-4 bg-accent" />
              <div className="flex items-start gap-4">
                <div className="p-2 bg-accent/10 border-2 border-accent">
                  <MessageSquare size={20} className="text-accent" />
                </div>
                <div>
                  <h3 className="font-bold text-foreground mb-1">Discord</h3>
                  <p className="text-foreground/60 font-medium">Hijo#0000</p>
                </div>
              </div>
            </div>

            {/* Social Links */}
            <div>
              <h3 className="font-bold text-foreground mb-4">Réseaux Sociaux</h3>
              <div className="flex gap-3">
                <a
                  href="#"
                  className="p-3 bg-secondary border-2 border-foreground/20 hover:border-accent transition-all duration-200"
                >
                  <Github size={20} className="text-foreground" />
                </a>
                <a
                  href="#"
                  className="p-3 bg-secondary border-2 border-foreground/20 hover:border-accent transition-all duration-200"
                >
                  <Twitter size={20} className="text-foreground" />
                </a>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <form onSubmit={handleSubmit} className="space-y-4 animate-in fade-in slide-in-from-right-8 duration-500">
            <div>
              <label className="block text-sm font-bold text-foreground mb-2">
                Nom
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 bg-secondary border-2 border-foreground/20 text-foreground placeholder-foreground/40 focus:outline-none focus:border-accent transition-colors duration-200"
                placeholder="Votre nom"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-foreground mb-2">
                Email
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 bg-secondary border-2 border-foreground/20 text-foreground placeholder-foreground/40 focus:outline-none focus:border-accent transition-colors duration-200"
                placeholder="votre@email.com"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-foreground mb-2">
                Sujet
              </label>
              <input
                type="text"
                name="subject"
                value={formData.subject}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 bg-secondary border-2 border-foreground/20 text-foreground placeholder-foreground/40 focus:outline-none focus:border-accent transition-colors duration-200"
                placeholder="Sujet de votre message"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-foreground mb-2">
                Message
              </label>
              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                required
                rows={5}
                className="w-full px-4 py-3 bg-secondary border-2 border-foreground/20 text-foreground placeholder-foreground/40 focus:outline-none focus:border-accent transition-colors duration-200 resize-none"
                placeholder="Votre message..."
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full px-6 py-3 bg-accent text-accent-foreground font-bold border-2 border-accent hover:bg-transparent hover:text-accent transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-accent-foreground/30 border-t-accent-foreground animate-spin" />
                  Envoi en cours...
                </>
              ) : (
                <>
                  <Send size={18} />
                  Envoyer le message
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
