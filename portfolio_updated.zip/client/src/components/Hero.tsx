import { ArrowRight, Code2 } from 'lucide-react';

/**
 * Hero Section - Original Geometric Design
 * Design Philosophy: Bold geometric shapes, asymmetric layout, distinctive patterns
 */

export default function Hero() {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20"
    >
      {/* Geometric Background Shapes */}
      <div className="absolute inset-0 z-0">
        {/* Large diagonal shape - top right */}
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-accent/20 transform rotate-45" />
        
        {/* Rotated square - bottom left */}
        <div className="absolute -bottom-32 -left-32 w-80 h-80 bg-accent/10 transform rotate-12" />
        
        {/* Hexagon pattern overlay */}
        <svg className="absolute inset-0 w-full h-full opacity-5" viewBox="0 0 1200 800">
          <defs>
            <pattern id="hexagons" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
              <polygon points="50,0 100,25 100,75 50,100 0,75 0,25" fill="none" stroke="currentColor" strokeWidth="1"/>
            </pattern>
          </defs>
          <rect width="1200" height="800" fill="url(#hexagons)" />
        </svg>
      </div>

      {/* Content */}
      <div className="relative z-10 container max-w-6xl mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8 animate-in fade-in slide-in-from-left-8 duration-1000">
            {/* Badge with geometric background */}
            <div className="inline-flex items-center gap-3 px-4 py-2 bg-secondary border-2 border-accent rounded-none transform -skew-x-12">
              <Code2 size={18} className="text-accent" />
              <span className="text-sm font-bold text-foreground transform skew-x-12">
                Graphiste & UI Artist
              </span>
            </div>

            {/* Main Heading */}
            <div>
              <h1 className="text-6xl md:text-7xl font-display font-black leading-tight mb-6 text-foreground">
                Bienvenue
              </h1>
              <p className="text-lg md:text-xl text-foreground/70 leading-relaxed max-w-xl">
                Je suis Hijo, graphiste et UI artist passionné. Je crée des designs innovants et visuellement captivants pour les jeux et applications modernes.
              </p>
            </div>

            {/* CTA Buttons with geometric styling */}
            <div className="flex flex-col sm:flex-row gap-4 pt-8">
              <a
                href="#scripts"
                className="group relative inline-flex items-center justify-center gap-2 px-6 py-3 font-bold text-accent-foreground bg-accent overflow-hidden"
              >
                {/* Diagonal stripe animation */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 group-hover:translate-x-full transition-transform duration-500" />
                <span className="relative flex items-center gap-2">
                  Voir mes projets
                  <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                </span>
              </a>
              <a
                href="#contact"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 font-bold text-foreground border-2 border-foreground hover:bg-foreground hover:text-background transition-all duration-200"
              >
                Me contacter
              </a>
            </div>

            {/* Stats with geometric dividers */}
            <div className="grid grid-cols-3 gap-6 pt-12 border-t-2 border-accent/30">
              <div className="relative pl-6">
                <div className="absolute left-0 top-0 w-1 h-8 bg-accent" />
                <div className="text-3xl font-black text-foreground">18+</div>
                <div className="text-sm text-foreground/60">Ans</div>
              </div>
              <div className="relative pl-6">
                <div className="absolute left-0 top-0 w-1 h-8 bg-accent" />
                <div className="text-3xl font-black text-foreground">6+</div>
                <div className="text-sm text-foreground/60">Projets</div>
              </div>
              <div className="relative pl-6">
                <div className="absolute left-0 top-0 w-1 h-8 bg-accent" />
                <div className="text-3xl font-black text-foreground">100%</div>
                <div className="text-sm text-foreground/60">Dédié</div>
              </div>
            </div>
          </div>

          {/* Right Geometric Element */}
          <div className="hidden md:flex items-center justify-center animate-in fade-in slide-in-from-right-8 duration-1000">
            <div className="relative w-96 h-96">
              {/* Large rotated square */}
              <div className="absolute inset-0 border-4 border-accent transform rotate-45" />
              
              {/* Inner rotated square */}
              <div className="absolute inset-8 border-2 border-accent/50 transform rotate-45" />
              
              {/* Diagonal lines */}
              <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 400">
                <line x1="0" y1="0" x2="400" y2="400" stroke="currentColor" strokeWidth="2" className="text-accent/30" />
                <line x1="400" y1="0" x2="0" y2="400" stroke="currentColor" strokeWidth="2" className="text-accent/30" />
                <circle cx="200" cy="200" r="100" fill="none" stroke="currentColor" strokeWidth="2" className="text-accent/40" />
              </svg>

              {/* Floating geometric shapes */}
              <div className="absolute top-12 right-12 w-16 h-16 bg-accent/10 transform rotate-12" />
              <div className="absolute bottom-20 left-8 w-12 h-12 bg-accent/20 transform -rotate-45" />
              <div className="absolute top-1/2 left-1/2 w-24 h-24 border-2 border-accent/30 transform -translate-x-1/2 -translate-y-1/2 rotate-45" />
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 animate-bounce">
        <div className="flex flex-col items-center gap-2">
          <span className="text-xs text-muted-foreground font-bold">SCROLL</span>
          <div className="w-1 h-8 border-2 border-foreground/20 flex justify-center">
            <div className="w-0.5 h-2 bg-foreground/40 animate-pulse" />
          </div>
        </div>
      </div>
    </section>
  );
}
