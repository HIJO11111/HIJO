import { Github, Twitter, Mail, Heart } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative border-t-2 border-foreground/10 bg-background">
      {/* Geometric background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-accent/5 transform rotate-45" />
      </div>

      <div className="container relative z-10 py-16">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-accent border-2 border-foreground transform rotate-45" />
              <div className="text-xl font-black text-foreground">HIJO</div>
            </div>
            <p className="text-sm text-foreground/60 font-medium">
              Développeur FiveM passionné créant des scripts innovants et performants.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-black text-foreground mb-4 text-sm">NAVIGATION</h4>
            <ul className="space-y-2">
              <li>
                <a href="#hero" className="text-sm text-foreground/60 hover:text-accent transition-colors font-medium">
                  Accueil
                </a>
              </li>
              <li>
                <a href="#scripts" className="text-sm text-foreground/60 hover:text-accent transition-colors font-medium">
                  Scripts
                </a>
              </li>
              <li>
                <a href="#skills" className="text-sm text-foreground/60 hover:text-accent transition-colors font-medium">
                  Compétences
                </a>
              </li>
              <li>
                <a href="#contact" className="text-sm text-foreground/60 hover:text-accent transition-colors font-medium">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="font-black text-foreground mb-4 text-sm">RESSOURCES</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-sm text-foreground/60 hover:text-accent transition-colors font-medium">
                  Documentation
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-foreground/60 hover:text-accent transition-colors font-medium">
                  GitHub
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-foreground/60 hover:text-accent transition-colors font-medium">
                  Blog
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-foreground/60 hover:text-accent transition-colors font-medium">
                  Support
                </a>
              </li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h4 className="font-black text-foreground mb-4 text-sm">SUIVEZ-MOI</h4>
            <div className="flex gap-3">
              <a
                href="#"
                className="p-2 bg-secondary border-2 border-foreground/20 hover:border-accent transition-all duration-200"
              >
                <Github size={18} className="text-foreground" />
              </a>
              <a
                href="#"
                className="p-2 bg-secondary border-2 border-foreground/20 hover:border-accent transition-all duration-200"
              >
                <Twitter size={18} className="text-foreground" />
              </a>
              <a
                href="mailto:contact@hijo.dev"
                className="p-2 bg-secondary border-2 border-foreground/20 hover:border-accent transition-all duration-200"
              >
                <Mail size={18} className="text-foreground" />
              </a>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t-2 border-foreground/10 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-foreground/60 flex items-center gap-2 font-medium">
              Fait avec <Heart size={16} className="text-accent fill-accent" /> par Hijo
            </p>
            <p className="text-sm text-foreground/60 font-medium">
              © {currentYear} Hijo Portfolio. Tous droits réservés.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
