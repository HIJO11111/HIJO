import Header from '@/components/Header';
import Hero from '@/components/Hero';
import ScriptsSection from '@/components/ScriptsSection';
import SkillsSection from '@/components/SkillsSection';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';

/**
 * Home Page - Main Portfolio Page
 * Design Philosophy: Cyberpunk Futuristic with neon accents and smooth animations
 * Sections: Hero, Scripts Showcase, Skills, Contact, Footer
 */

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header Navigation */}
      <Header />

      {/* Main Content */}
      <main className="overflow-hidden">
        {/* Hero Section */}
        <Hero />

        {/* Scripts Section */}
        <ScriptsSection />

        {/* Skills Section */}
        <SkillsSection />

        {/* Contact Section */}
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
