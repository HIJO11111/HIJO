import { Code2, Zap, Cpu, Layers } from 'lucide-react';

interface Skill {
  category: string;
  icon: React.ReactNode;
  skills: string[];
}

const skillsData: Skill[] = [
  {
    category: 'Languages',
    icon: <Code2 size={24} />,
    skills: ['Lua', 'JavaScript', 'TypeScript', 'Python'],
  },
  {
    category: 'FiveM Development',
    icon: <Zap size={24} />,
    skills: ['Client Scripts', 'Server Scripts', 'NUI Development', 'Database Integration'],
  },
  {
    category: 'Tools & Frameworks',
    icon: <Cpu size={24} />,
    skills: ['React', 'Node.js', 'Git', 'MySQL', 'Redis'],
  },
  {
    category: 'Specializations',
    icon: <Layers size={24} />,
    skills: ['Game Mechanics', 'Performance Optimization', 'API Design', 'System Architecture'],
  },
];

export default function SkillsSection() {
  return (
    <section id="skills" className="relative py-24 overflow-hidden">
      {/* Geometric background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 left-0 w-96 h-96 bg-accent/5 transform -rotate-45" />
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-accent/5 transform rotate-12" />
      </div>

      <div className="container relative z-10">
        {/* Section Header */}
        <div className="mb-16">
          <div className="inline-flex items-center gap-3 px-4 py-2 bg-secondary border-2 border-accent mb-6 transform -skew-x-12">
            <span className="text-sm font-bold text-accent transform skew-x-12">COMPÉTENCES</span>
          </div>
          <h2 className="text-5xl md:text-6xl font-display font-black mb-4 text-foreground">
            Mes Expertises
          </h2>
          <p className="text-lg text-foreground/60 max-w-2xl">
            Une combinaison de compétences techniques et créatives pour développer des solutions FiveM de qualité professionnelle.
          </p>
        </div>

        {/* Skills Grid */}
        <div className="grid md:grid-cols-2 gap-6 max-w-4xl">
          {skillsData.map((skill, index) => (
            <div
              key={skill.category}
              className="group relative animate-in fade-in slide-in-from-bottom-4 duration-500"
              style={{
                animationDelay: `${index * 100}ms`,
              }}
            >
              {/* Geometric card */}
              <div className="relative p-8 bg-secondary border-2 border-foreground/20 hover:border-accent transition-all duration-200">
                {/* Decorative elements */}
                <div className="absolute -top-3 -left-3 w-6 h-6 bg-accent transform rotate-45" />
                <div className="absolute -bottom-3 -right-3 w-6 h-6 bg-accent/50 transform rotate-45" />

                {/* Icon with background */}
                <div className="inline-flex p-3 bg-accent/10 border-2 border-accent mb-4 text-accent">
                  {skill.icon}
                </div>

                {/* Title */}
                <h3 className="text-lg font-black mb-4 text-foreground">
                  {skill.category}
                </h3>

                {/* Skills List */}
                <div className="space-y-3">
                  {skill.skills.map((item) => (
                    <div key={item} className="flex items-center gap-3 pl-2 border-l-2 border-accent">
                      <span className="text-foreground/70 text-sm font-medium">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Learning Section with geometric design */}
        <div className="mt-16 relative p-8 bg-secondary border-2 border-foreground/20">
          {/* Corner decorations */}
          <div className="absolute -top-2 -left-2 w-4 h-4 bg-accent" />
          <div className="absolute -top-2 -right-2 w-4 h-4 bg-accent" />
          <div className="absolute -bottom-2 -left-2 w-4 h-4 bg-accent" />
          <div className="absolute -bottom-2 -right-2 w-4 h-4 bg-accent" />

          <p className="text-foreground/70 mb-4 text-center">
            Toujours en apprentissage et à la recherche de nouvelles technologies pour améliorer mes compétences.
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            {['Lua', 'JavaScript', 'React', 'Node.js', 'FiveM', 'MySQL'].map((tech) => (
              <span
                key={tech}
                className="px-3 py-1 bg-background border-2 border-foreground/20 text-foreground/70 text-xs font-bold hover:border-accent transition-colors"
              >
                {tech}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
