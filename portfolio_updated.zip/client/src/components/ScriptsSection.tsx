import { useState } from 'react';
import { ExternalLink, Star } from 'lucide-react';

interface Script {
  id: string;
  title: string;
  description: string;
  category: 'UI Design' | 'Web Design' | 'Game Interface' | 'HUD System';
  rating: number;
  features: string[];
  image: string;
  demo?: string;
}

const scripts: Script[] = [
  {
    id: '1',
    title: 'Car LockPick Script UI',
    description: 'Une interface de crochetage de véhicule élégante et interactive. Elle présente un design circulaire avec des goupilles dorées et un indicateur de statut en temps réel pour une expérience immersive.',
    category: 'UI Design',
    rating: 5,
    features: ['Design Circulaire', 'Feedback Visuel', 'Style Moderne'],
    image: '/projects/Frame 1.png',
    demo: '#',
  },
  {
    id: '2',
    title: 'Hijo Landing Page',
    description: 'Une page d\'accueil complète pour un serveur de jeu, mettant en avant un style sombre et luxueux avec des visuels de voitures de sport et d\'équipements tactiques.',
    category: 'Web Design',
    rating: 5,
    features: ['Responsive', 'Style Sombre', 'Navigation Intuitive'],
    image: '/projects/Frame 1 (1).png',
    demo: '#',
  },
  {
    id: '3',
    title: 'Vehicle Stealing Mission UI',
    description: 'Interface utilisateur pour un système de missions de vol de véhicules. Elle inclut des cartes de sélection de voitures, des barres de progression d\'expérience et une sélection de zones sur la carte.',
    category: 'Game Interface',
    rating: 5,
    features: ['Gestion XP', 'Sélection de Zone', 'Dashboard Joueur'],
    image: '/projects/Frame 1 (2).png',
    demo: '#',
  },
  {
    id: '4',
    title: 'House LockPick Script UI',
    description: 'Interface de mini-jeu de piratage/crochetage pour les maisons. Utilise un système de grille avec détection de trace et des retours visuels clairs pour le succès ou l\'échec.',
    category: 'UI Design',
    rating: 5,
    features: ['Mini-jeu Interactif', 'Système de Grille', 'Alertes Dynamiques'],
    image: '/projects/Frame 2.png',
    demo: '#',
  },
  {
    id: '5',
    title: 'HUD Status System (V1)',
    description: 'Un système de HUD (Heads-Up Display) pour les statistiques vitales du joueur (santé, armure, faim, soif). Propose plusieurs variantes de couleurs et de styles néon.',
    category: 'HUD System',
    rating: 5,
    features: ['Multi-couleurs', 'Style Néon', 'Indicateurs Dynamiques'],
    image: '/projects/Frame 3.png',
    demo: '#',
  },
  {
    id: '6',
    title: 'HUD Status System (V2)',
    description: 'Une version alternative et plus minimaliste du système de HUD, utilisant des icônes circulaires épurées avec des effets de lueur pour une meilleure lisibilité en jeu.',
    category: 'HUD System',
    rating: 5,
    features: ['Minimaliste', 'Icônes Circulaires', 'Effets de Lueur'],
    image: '/projects/Frame 4.png',
    demo: '#',
  },
];

const categories: Script['category'][] = ['UI Design', 'Web Design', 'Game Interface', 'HUD System'];

export default function ScriptsSection() {
  const [selectedCategory, setSelectedCategory] = useState<Script['category'] | 'All'>('All');

  const filteredScripts =
    selectedCategory === 'All'
      ? scripts
      : scripts.filter((script) => script.category === selectedCategory);

  return (
    <section id="scripts" className="relative py-24 overflow-hidden">
      {/* Geometric background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-20 right-0 w-96 h-96 bg-accent/5 transform rotate-45" />
        <div className="absolute -bottom-40 left-1/4 w-80 h-80 bg-accent/5 transform -rotate-12" />
      </div>

      <div className="container relative z-10">
        {/* Section Header */}
        <div className="mb-16">
          <div className="inline-flex items-center gap-3 px-4 py-2 bg-secondary border-2 border-accent mb-6 transform -skew-x-12">
            <span className="text-sm font-bold text-accent transform skew-x-12">PORTFOLIO</span>
          </div>
          <h2 className="text-5xl md:text-6xl font-display font-black mb-4 text-foreground">
            Mes Projets Graphiques
          </h2>
          <p className="text-lg text-foreground/60 max-w-2xl">
            Une collection de designs UI/UX innovants et visuellement captivants pour les jeux et applications.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-3 mb-12">
          <button
            onClick={() => setSelectedCategory('All')}
            className={`px-4 py-2 font-bold text-sm transition-all duration-200 border-2 ${
              selectedCategory === 'All'
                ? 'bg-foreground text-background border-foreground'
                : 'bg-transparent text-foreground border-foreground/30 hover:border-foreground'
            }`}
          >
            Tous
          </button>
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 font-bold text-sm transition-all duration-200 border-2 ${
                selectedCategory === category
                  ? 'bg-foreground text-background border-foreground'
                  : 'bg-transparent text-foreground border-foreground/30 hover:border-foreground'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Scripts Grid - Asymmetric Layout */}
        <div className="grid gap-6 auto-rows-max">
          {filteredScripts.map((script, index) => {
            const isLarge = index % 3 === 0;
            return (
              <div
                key={script.id}
                className={`group relative animate-in fade-in slide-in-from-bottom-4 duration-500 ${
                  isLarge ? 'md:col-span-2' : ''
                }`}
                style={{
                  animationDelay: `${index * 100}ms`,
                  display: 'grid',
                  gridTemplateColumns: isLarge ? '1fr 1fr' : '1fr',
                  gap: '1.5rem',
                }}
              >
                {/* Image Section */}
                <div className="relative overflow-hidden bg-secondary border-2 border-foreground/20 hover:border-accent transition-all duration-200 group-hover:shadow-lg">
                  <img
                    src={script.image}
                    alt={script.title}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Card with geometric border */}
                <div className="relative p-6 bg-secondary border-2 border-foreground/20 hover:border-accent transition-all duration-200 group-hover:shadow-lg">
                  {/* Decorative corner */}
                  <div className="absolute -top-2 -right-2 w-4 h-4 bg-accent" />
                  <div className="absolute -bottom-2 -left-2 w-4 h-4 bg-accent" />

                  {/* Content */}
                  <div className="space-y-3">
                    <div className="inline-flex">
                      <span className="px-2 py-1 bg-accent/10 text-accent text-xs font-bold border border-accent/30">
                        {script.category}
                      </span>
                    </div>

                    <h3 className="text-lg font-black text-foreground">
                      {script.title}
                    </h3>

                    <p className="text-sm text-foreground/60">
                      {script.description}
                    </p>

                    {/* Rating */}
                    <div className="flex items-center gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          size={14}
                          className={i < script.rating ? 'fill-accent text-accent' : 'text-muted'}
                        />
                      ))}
                      <span className="text-xs text-muted-foreground ml-2">({script.rating}/5)</span>
                    </div>

                    {/* Features */}
                    <div className="flex flex-wrap gap-2">
                      {script.features.map((feature) => (
                        <span key={feature} className="text-xs px-2 py-1 bg-background border border-foreground/10 text-foreground/70">
                          {feature}
                        </span>
                      ))}
                    </div>

                    {/* Links */}
                    <div className="flex gap-2 pt-4 border-t-2 border-foreground/10">
                      {script.demo && (
                        <a
                          href={script.demo}
                          className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-accent/10 border-2 border-accent text-sm text-accent font-bold hover:bg-accent hover:text-background transition-all duration-200"
                        >
                          <ExternalLink size={16} />
                          <span className="hidden sm:inline">Voir</span>
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
