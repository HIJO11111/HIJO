import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Accueil', href: '#hero' },
    { label: 'Projets', href: '#scripts' },
    { label: 'Compétences', href: '#skills' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <header
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-background/95 backdrop-blur-md border-b-2 border-foreground/10'
          : 'bg-transparent'
      }`}
    >
      <nav className="container flex items-center justify-between h-16">
        {/* Logo with geometric style */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 bg-accent border-2 border-foreground transform rotate-45" />
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-xs font-black text-background transform -rotate-45">H</span>
            </div>
          </div>
          <div>
            <div className="text-lg font-black text-foreground">HIJO</div>
            <div className="text-xs font-bold text-foreground/60">GRAPHISTE</div>
          </div>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <a
              key={item.label}
              href={item.href}
              className="text-sm font-bold text-foreground/70 hover:text-foreground transition-colors duration-200 relative group"
            >
              {item.label}
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-accent group-hover:w-full transition-all duration-300" />
            </a>
          ))}
        </div>

        {/* CTA Button */}
        <div className="hidden md:flex">
          <a
            href="#contact"
            className="px-4 py-2 text-sm font-bold text-accent-foreground bg-accent border-2 border-accent hover:bg-transparent hover:text-accent transition-all duration-200"
          >
            Contact
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="md:hidden p-2 text-foreground hover:text-accent transition-colors"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-background border-b-2 border-foreground/10 animate-in fade-in slide-in-from-top-2 duration-200">
          <nav className="container py-4 flex flex-col gap-4">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="text-foreground/70 hover:text-foreground transition-colors duration-200 py-2 font-bold"
                onClick={() => setIsOpen(false)}
              >
                {item.label}
              </a>
            ))}
            <a
              href="#contact"
              className="mt-4 px-4 py-2 bg-accent text-accent-foreground font-bold border-2 border-accent text-center hover:bg-transparent hover:text-accent transition-all duration-200"
              onClick={() => setIsOpen(false)}
            >
              Contact
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
